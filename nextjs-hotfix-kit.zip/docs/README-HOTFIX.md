# Next.js Client Runtime Hotfix Kit

## Add these
- `app/providers.tsx` (client providers for Theme/Intl)
- `app/error.tsx` (error boundary to avoid black screen)
- `app/layout.example.tsx` (server-only layout reference)
- `scripts/grep-sweep.sh` (quick scan for offenders)

## Do this
1. Ensure `app/layout.tsx` is NOT a client component.
2. Move `window`/`document`/`localStorage`/`matchMedia` into `useEffect`.
3. Remove `async` from client components; fetch in `useEffect` instead.
4. Dynamically import `jspdf`/`xlsx`/`mic-recorder-to-mp3` with `await import(...)`.
5. Keep `stripe`/`twilio`/`redis`/`airtable`/`dotenv` server-side only.
6. (Optional) enable production source maps to see real stack traces.

## Verify
```bash
pnpm build && pnpm start
```
