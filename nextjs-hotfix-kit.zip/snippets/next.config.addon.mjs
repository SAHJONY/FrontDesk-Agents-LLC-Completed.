/** @type {import('next').NextConfig} */
const addon = {
  productionBrowserSourceMaps: true,
};
export default addon;
