# Next.js Client Crash Hotfix Kit (Vercel "Application error: a client-side exception has occurred")

This kit contains drop-in files and a quick diagnostic sweep to fix the common production-only
client crashes in **Next.js App Router** (e.g., after adding a ThemeProvider). It’s safe to add,
and you can selectively copy/merge into your project.

## What’s included

- `app/providers.tsx` – Moves all client-only providers (e.g., `next-themes`) out of `app/layout.tsx`.
- `app/error.tsx` – App Router error boundary to prevent black screen and surface the real error.
- `app/layout.example.tsx` – A correct **server** layout for reference. Compare with your own layout.
- `components/Exporter.example.tsx` – Shows how to dynamically import browser-only libs (`jspdf`, `xlsx`).
- `snippets/next.config.addon.mjs` – Optional: enable production browser source maps to see stack traces.
- `scripts/grep-sweep.sh` – Ripgrep sweep to locate the usual offenders in your repo.

## Quick start

1. **Copy files** (non-destructive):
   - If you **do not** already have `app/providers.tsx`, copy ours into your `app/` directory.
   - If you **do not** already have `app/error.tsx`, copy ours into your `app/` directory.
   - Do **not** overwrite your `app/layout.tsx`. Instead, open `app/layout.example.tsx` and align your file:
     - Ensure **no** `"use client"` at the top of `app/layout.tsx`.
     - Keep `<html lang="en" suppressHydrationWarning>`.
     - Wrap `<Providers>{children}</Providers>` inside `<body>` and import from `./providers`.
     - Keep `export const metadata = { ... }` only in **server** files.

2. **Refactor offenders**:
   - Any `"use client"` component must **not** be `async` and must **not** use top-level `await`.
   - Move all usage of `window`, `document`, `localStorage`, `matchMedia` into `useEffect`.
   - Import browser-only libraries (`jspdf`, `xlsx`, `mic-recorder-to-mp3`) **dynamically** via `await import(...)`.

3. **(Optional) Add source maps in production**:
   - Open your `next.config.mjs` and merge the snippet from `snippets/next.config.addon.mjs`.
   - Remove later if you don’t want to ship source maps.

4. **Run the grep sweep** (requires `rg` installed):
   ```bash
   bash scripts/grep-sweep.sh
   ```
   Fix each hit per the notes in the script output comments.

5. **Verify in true production locally**:
   ```bash
   pnpm build
   pnpm start
   # open http://localhost:3000 and check the browser console for the first red error
   ```

## Notes for `next-themes`
- Keep `attribute="class"` on `ThemeProvider` (see `app/providers.tsx`).
- Avoid reading/writing theme at module scope (use `useEffect` instead).
- Using `suppressHydrationWarning` on `<html>` helps avoid transient mismatch warnings.

## Need exact pinpoint?
After adding `app/error.tsx`, the screen will show the real error. Grab the **first** red line from the console
(message + top stack frame) and fix that file/line. If you share that single line, we can give you the exact patch.
