// Merge this into your existing next.config.mjs
/** @type {import('next').NextConfig} */
const addon = {
  // Temporary: ship browser source maps to see stack traces in production.
  productionBrowserSourceMaps: true,
};

export default addon;
