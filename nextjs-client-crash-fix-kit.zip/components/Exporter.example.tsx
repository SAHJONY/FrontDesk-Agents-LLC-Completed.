"use client";
import * as React from "react";

export default function ExporterExample() {
  const handlePDF = async () => {
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF();
    doc.text("Hello from jsPDF", 10, 10);
    doc.save("example.pdf");
  };

  const handleXLSX = async () => {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet([["A", "B"], ["1", "2"]]);
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "example.xlsx");
  };

  const handleMic = async () => {
    const { default: MicRecorder } = await import("mic-recorder-to-mp3");
    const rec = new MicRecorder({ bitRate: 128 });
    try {
      await rec.start();
      // Call rec.stop().getMp3() later…
      alert("Recording started (example).");
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div style={{ display: "flex", gap: 8 }}>
      <button onClick={handlePDF}>Make PDF</button>
      <button onClick={handleXLSX}>Make XLSX</button>
      <button onClick={handleMic}>Init Mic</button>
    </div>
  );
}
