# FrontDesk Command Center – Deployment Guide

## Overview

This guide walks you through deploying the FrontDesk Command Center to GitHub and Vercel. The project is a Next.js application with Prisma ORM, Airtable integration, and Outlook email automation.

## Prerequisites

- GitHub account
- Vercel account (free tier available)
- Node.js 18+ and npm installed locally
- PostgreSQL database (for production)
- Airtable account with API key
- Outlook email account with app password

## Step 1: Prepare Your Local Environment

1. **Clone or download the project:**
   ```bash
   cd frontdesk-command-center-final
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Create `.env.local` file:**
   ```bash
   cp .env.example .env.local
   ```

4. **Update environment variables in `.env.local`:**
   ```
   DATABASE_URL=postgres://user:password@localhost:5432/frontdesk
   AIRTABLE_API_KEY=keyXXXXXXXXXXXX
   AIRTABLE_BASE_ID=appXXXXXXXXXXXX
   SMTP_PASS=your-outlook-app-password
   ```

## Step 2: Set Up Database (Prisma)

1. **Generate Prisma client:**
   ```bash
   npx prisma generate
   ```

2. **Push schema to database:**
   ```bash
   npx prisma db push
   ```

3. **Verify database connection:**
   ```bash
   npx prisma studio
   ```

## Step 3: Test Locally

1. **Start development server:**
   ```bash
   npm run dev
   ```

2. **Access the application:**
   - Command Center: http://localhost:3000/command-center
   - Insights: http://localhost:3000/dashboard/insights

## Step 4: Push to GitHub

1. **Create a new repository on GitHub:**
   - Go to https://github.com/new
   - Name: `FrontDesk-Agents-LLC-Completed`
   - Make it Public (for Vercel to access)

2. **Add remote and push:**
   ```bash
   git remote add origin https://github.com/SAHJONY/FrontDesk-Agents-LLC-Completed.git
   git branch -M main
   git push -u origin main
   ```

## Step 5: Deploy to Vercel

1. **Connect to Vercel:**
   - Go to https://vercel.com/new
   - Click "Import Git Repository"
   - Select your GitHub repository

2. **Configure project:**
   - Framework: Next.js
   - Root Directory: ./
   - Build Command: `npm run build`
   - Install Command: `npm install`

3. **Add environment variables in Vercel:**
   - `DATABASE_URL`: Your production PostgreSQL URL
   - `AIRTABLE_API_KEY`: Your Airtable API key
   - `AIRTABLE_BASE_ID`: Your Airtable base ID
   - `SMTP_PASS`: Your Outlook app password

4. **Set custom domain:**
   - In Vercel dashboard, go to Settings → Domains
   - Add `www.frontdeskagents.com`
   - Update DNS records at your domain registrar

## Step 6: Verify Deployment

1. **Check Vercel deployment:**
   - Visit https://front-desk-agents-llc-completed.vercel.app
   - Or your custom domain once DNS propagates

2. **Test API endpoints:**
   - Automation endpoint: `/api/automation/send-followups`

3. **Monitor logs:**
   - Vercel dashboard → Deployments → View logs

## Troubleshooting

### "Repository not found" error
- Ensure the GitHub repository is public
- Verify the PAT (Personal Access Token) has correct permissions

### Database connection issues
- Verify `DATABASE_URL` format
- Ensure PostgreSQL server is running
- Check firewall rules for database access

### Email automation not working
- Verify Airtable API key and base ID
- Ensure Outlook app password is correct
- Check SMTP credentials in Outlook account settings

### Build failures on Vercel
- Check build logs in Vercel dashboard
- Ensure all environment variables are set
- Verify Node.js version compatibility

## Maintenance

### Regular updates
```bash
npm update
npx prisma migrate dev
```

### Database backups
- Enable automated backups in your PostgreSQL provider
- Regularly export Airtable data

### Monitoring
- Set up Vercel Analytics
- Monitor API usage and errors
- Track email delivery rates

## Security Best Practices

1. **Never commit `.env.local`** – it's in `.gitignore`
2. **Use strong passwords** for database and Outlook
3. **Rotate API keys** periodically
4. **Enable 2FA** on GitHub and Vercel accounts
5. **Review Vercel logs** for suspicious activity

## Support

For issues or questions:
- Check Vercel documentation: https://vercel.com/docs
- Review Next.js guide: https://nextjs.org/docs
- Contact FrontDesk support team

---

**Deployment Status:** Ready for production  
**Last Updated:** November 2025
