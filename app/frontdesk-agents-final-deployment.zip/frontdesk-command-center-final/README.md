# FrontDesk Command Center

AI-powered Command Center for FrontDesk Agents LLC  
Built with Next.js + Prisma + Airtable + Outlook Automation

## Setup

1. **Clone the repository:**
   ```bash
   git clone https://github.com/SAHJONY/FrontDesk-Agents-LLC-Completed.git
   cd FrontDesk-Agents-LLC-Completed
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up .env:**
   Create a `.env.local` file in the root directory with the following variables:
   ```
   DATABASE_URL=postgres://user:password@db:5432/frontdesk
   AIRTABLE_API_KEY=keyXXXXXXXXXXXX
   AIRTABLE_BASE_ID=appXXXXXXXXXXXX
   SMTP_PASS=your-outlook-app-password
   ```

4. **Run Prisma:**
   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Start Dev Server:**
   ```bash
   npm run dev
   ```

6. **Deploy on Vercel:**
   - Connect your GitHub repository to Vercel
   - Add the environment variables in Vercel dashboard
   - Set custom domain: www.frontdeskagents.com

## Integrations

- **Bland.ai** for voice automation
- **Airtable** for lead management
- **Outlook SMTP** for email automation
- **Square Payments** (planned)

## Features

- **Command Center Dashboard** for real-time calls, leads & appointments
- **Automated Revenue Loop** via `/api/automation/send-followups`
- **Revenue & Performance Insights** with interactive charts
- **Multi-department Email Templates** (Sales, Support, Billing, Operations, SARA)

## Project Structure

```
frontdesk-command-center-final/
├── app/
│   ├── api/
│   │   └── automation/send-followups.js
│   ├── dashboard/insights/page.tsx
│   └── command-center/page.tsx
├── lib/renderEmail.js
├── prisma/schema.prisma
├── styles/globals.css
├── templates/
│   ├── sales.html
│   ├── support.html
│   ├── billing.html
│   ├── ops.html
│   └── sara.html
└── README.md
```

## Notes

This is your full production bundle. Once you copy these files into your repo and push to GitHub, Vercel will automatically deploy it to your connected domain (`www.frontdeskagents.com`).
