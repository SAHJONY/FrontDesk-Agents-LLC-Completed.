// lib/siteImages.ts

export type PageKey =
  | "home"
  | "pricing"
  | "demo"
  | "industries"
  | "setup"
  | "ai-agents"
  | "dashboard"
  | "dashboard-outbound"
  | "dashboard-retention"
  | "admin"
  | "login"
  | "support"
  | "legal";

type HeroConfig = {
  src: string;
  alt: string;
};

const HERO_IMAGES: Record<PageKey, HeroConfig> = {
  home: {
    src: "/images/home/home-hero-4k.png",
    alt: "AI reception command center monitoring calls and messages for multiple businesses in real-time"
  },
  pricing: {
    src: "/images/pricing/pricing-hero-4k.png",
    alt: "Pricing dashboard showing different AI receptionist plans for businesses of all sizes"
  },
  demo: {
    src: "/images/demo/demo-hero-4k.png",
    alt: "Business owner on a live demo call reviewing the AI receptionist in action"
  },
  industries: {
    src: "/images/industries/industries-hero-4k.png",
    alt: "Grid of diverse industries using AI reception, from medical clinics to law firms"
  },
  setup: {
    src: "/images/setup/setup-hero-4k.png",
    alt: "Onboarding wizard showing the step-by-step setup of a new AI receptionist"
  },
  "ai-agents": {
    src: "/images/ai-agents/ai-agents-hero-4k.png",
    alt: "Multiple AI agents collaborating in a mission control style interface"
  },
  dashboard: {
    src: "/images/dashboard/client-dashboard-4k.png",
    alt: "Client dashboard with live metrics for calls, bookings, and captured leads"
  },
  "dashboard-outbound": {
    src: "/images/outbound/outbound-dashboard-4k.png",
    alt: "Outbound calling dashboard with active campaigns and performance charts"
  },
  "dashboard-retention": {
    src: "/images/retention/retention-dashboard-4k.png",
    alt: "Retention dashboard tracking follow-ups, callbacks, and returning customers"
  },
  admin: {
    src: "/images/admin/owner-console-4k.png",
    alt: "Owner console showing global configuration and high-level business metrics"
  },
  login: {
    src: "/images/login/login-hero-4k.png",
    alt: "Secure login interface for the FrontDesk Agents control panel"
  },
  support: {
    src: "/images/support/support-hero-4k.png",
    alt: "Support agent assisting a client with their AI receptionist configuration"
  },
  legal: {
    src: "/images/legal/legal-hero-4k.png",
    alt: "Legal and compliance overview for AI call recording and consent"
  }
};

export function getPageHero(page: PageKey): HeroConfig {
  // fallback to home hero if an unknown key is used
  return HERO_IMAGES[page] ?? HERO_IMAGES.home;
}
