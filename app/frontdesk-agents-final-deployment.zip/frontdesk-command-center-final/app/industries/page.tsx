import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Demo() {
  const hero = getPageHero("demo");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Live Demo</h1>
          <p className="text-lg md:text-2xl text-slate-200">See FrontDesk Agents in action</p>
        </div>
      </section>

      {/* Demo Content Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
          <h2 className="text-3xl font-bold text-white mb-6">Schedule Your Demo</h2>
          <p className="text-slate-300 mb-4">
            Experience the power of AI-driven reception firsthand. Our team will walk you through:
          </p>
          <ul className="space-y-3 text-slate-300 mb-8">
            <li>✓ Real-time call handling and routing</li>
            <li>✓ Intelligent message transcription</li>
            <li>✓ Advanced analytics dashboard</li>
            <li>✓ Integration with your existing systems</li>
          </ul>
          <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg">
            Book a Demo
          </button>
        </div>
      </section>
    </main>
  );
}
