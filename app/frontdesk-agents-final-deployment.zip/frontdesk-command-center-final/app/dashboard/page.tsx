import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function AIAgents() {
  const hero = getPageHero("ai-agents");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">AI Agents</h1>
          <p className="text-lg md:text-2xl text-slate-200">Intelligent virtual receptionists</p>
        </div>
      </section>

      {/* AI Agents Features Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-white mb-8">Meet Your AI Team</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { name: "Call Handler", capability: "Answers and routes calls intelligently" },
            { name: "Message Manager", capability: "Transcribes and categorizes messages" },
            { name: "Appointment Scheduler", capability: "Books and manages appointments" },
            { name: "Lead Qualifier", capability: "Qualifies and scores leads" },
            { name: "Follow-up Agent", capability: "Sends timely follow-up communications" },
            { name: "Analytics Engine", capability: "Provides real-time insights" }
          ].map((agent, idx) => (
            <div key={idx} className="bg-slate-800 rounded-lg p-6 border border-slate-700 hover:border-blue-500 transition">
              <h3 className="text-lg font-bold text-white mb-2">{agent.name}</h3>
              <p className="text-slate-300">{agent.capability}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
