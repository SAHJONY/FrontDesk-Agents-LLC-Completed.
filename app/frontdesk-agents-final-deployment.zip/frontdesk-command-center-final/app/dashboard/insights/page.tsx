"use client";
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function InsightsPage() {
  const [metrics, setMetrics] = useState<Array<{day: string; calls: number; leads: number}>>([]);

  useEffect(() => {
    // Simulate API
    setMetrics([
      { day: "Mon", calls: 120, leads: 45 },
      { day: "Tue", calls: 134, leads: 53 },
      { day: "Wed", calls: 102, leads: 40 },
      { day: "Thu", calls: 175, leads: 60 },
      { day: "Fri", calls: 190, leads: 72 }
    ]);
  }, []);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Revenue & Performance Insights</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <MetricCard label="Total Calls" value="721" />
        <MetricCard label="New Leads" value="270" />
        <MetricCard label="Appointments Booked" value="112" />
      </div>
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Leads per Day</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={metrics}>
            <XAxis dataKey="day" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="leads" stroke="#2b59c3" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const MetricCard = ({ label, value }: any) => (
  <div className="bg-white rounded-lg shadow p-6 text-center">
    <div className="text-gray-500 text-sm">{label}</div>
    <div className="text-2xl font-bold text-blue-600 mt-2">{value}</div>
  </div>
);
