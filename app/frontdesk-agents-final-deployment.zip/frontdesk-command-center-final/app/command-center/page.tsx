"use client";
import React from "react";

export default function CommandCenter() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">FrontDesk Command Center</h1>
      <p className="text-gray-600 mb-8">
        Live overview of all calls, leads, and appointments handled by your AI receptionists.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Widget title="Total Calls Today" value="84" />
        <Widget title="Missed Calls" value="6" />
        <Widget title="Leads Captured" value="31" />
      </div>
      <div className="mt-10 bg-white p-6 shadow rounded-lg">
        <h2 className="font-semibold text-lg mb-4">Recent Calls</h2>
        <table className="min-w-full">
          <thead>
            <tr className="border-b text-left text-sm text-gray-500">
              <th>Time</th>
              <th>Caller</th>
              <th>Status</th>
              <th>Summary</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>9:14 AM</td><td>+1 (512) 555-0193</td><td>Answered</td><td>Booking Inquiry</td></tr>
            <tr><td>10:21 AM</td><td>+1 (210) 555-4471</td><td>Missed</td><td>Follow-up Scheduled</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Widget({ title, value }: any) {
  return (
    <div className="bg-white rounded-lg shadow p-6 text-center">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-3xl font-bold text-blue-600 mt-2">{value}</div>
    </div>
  );
}
