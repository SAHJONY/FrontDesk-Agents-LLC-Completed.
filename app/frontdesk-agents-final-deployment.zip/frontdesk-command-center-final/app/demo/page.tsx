import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Pricing() {
  const hero = getPageHero("pricing");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Pricing Plans</h1>
          <p className="text-lg md:text-2xl text-slate-200">Choose the perfect plan for your business</p>
        </div>
      </section>

      {/* Pricing Cards Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { name: "Starter", price: "$99", features: ["Up to 100 calls/month", "Basic Analytics", "Email Support"] },
            { name: "Professional", price: "$299", features: ["Up to 1000 calls/month", "Advanced Analytics", "Priority Support"], highlighted: true },
            { name: "Enterprise", price: "Custom", features: ["Unlimited calls", "Custom Integration", "Dedicated Support"] }
          ].map((plan, idx) => (
            <div
              key={idx}
              className={`rounded-lg p-8 border ${
                plan.highlighted
                  ? "bg-blue-600 border-blue-500 ring-2 ring-blue-400"
                  : "bg-slate-800 border-slate-700"
              }`}
            >
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-3xl font-bold text-white mb-6">{plan.price}</p>
              <ul className="space-y-3 text-slate-300">
                {plan.features.map((feature, fidx) => (
                  <li key={fidx}>✓ {feature}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
