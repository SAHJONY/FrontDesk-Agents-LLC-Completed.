import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Home() {
  const hero = getPageHero("home");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">FrontDesk Agents Network</h1>
          <p className="text-lg md:text-2xl text-slate-200">AI Receptionist Command Center</p>
        </div>
      </section>

      {/* Content Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-4">Welcome to FrontDesk Agents</h2>
            <p className="text-slate-300 mb-4">
              Transform your business communications with our AI-powered receptionist system.
            </p>
            <p className="text-slate-300">
              Manage calls, messages, and customer interactions seamlessly across all channels.
            </p>
          </div>
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">Key Features</h3>
            <ul className="space-y-2 text-slate-300">
              <li>✓ 24/7 AI Reception</li>
              <li>✓ Multi-channel Support</li>
              <li>✓ Real-time Analytics</li>
              <li>✓ Enterprise Security</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}
