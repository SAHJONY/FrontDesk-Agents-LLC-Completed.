import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "@/styles/globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "FrontDesk Agents - AI Receptionist Command Center",
  description: "Transform your business communications with our AI-powered receptionist system.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="text-white font-bold text-xl">FrontDesk Agents</div>
            <ul className="flex gap-6 text-slate-300">
              <li><a href="/" className="hover:text-white transition">Home</a></li>
              <li><a href="/industries" className="hover:text-white transition">Industries</a></li>
              <li><a href="/pricing" className="hover:text-white transition">Pricing</a></li>
              <li><a href="/demo" className="hover:text-white transition">Demo</a></li>
              <li><a href="/support" className="hover:text-white transition">Support</a></li>
              <li><a href="/login" className="hover:text-white transition">Login</a></li>
            </ul>
          </div>
        </nav>
        {children}
        <footer className="bg-slate-900 border-t border-slate-800 mt-16">
          <div className="max-w-6xl mx-auto px-4 py-8 text-center text-slate-400">
            <p>&copy; 2024 FrontDesk Agents LLC. All rights reserved.</p>
            <div className="mt-4 space-x-4">
              <a href="/legal" className="hover:text-white transition">Terms</a>
              <a href="/legal" className="hover:text-white transition">Privacy</a>
              <a href="/support" className="hover:text-white transition">Contact</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
