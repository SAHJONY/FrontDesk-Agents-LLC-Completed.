import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Login() {
  const hero = getPageHero("login");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      <div className="flex h-screen">
        {/* Hero Image Section */}
        <div className="hidden md:flex md:w-1/2 relative overflow-hidden">
          <Image
            src={hero.src}
            alt={hero.alt}
            fill
            priority
            className="object-cover"
          />
          <div className="absolute inset-0 bg-black/20"></div>
        </div>

        {/* Login Form Section */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">Sign In</h1>
              <p className="text-slate-400">Access your FrontDesk Agents account</p>
            </div>

            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">Email Address</label>
                <input
                  type="email"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  placeholder="you@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">Password</label>
                <input
                  type="password"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  placeholder="••••••••"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition"
              >
                Sign In
              </button>
            </form>

            <p className="text-center text-slate-400 mt-6">
              Don't have an account? <a href="#" className="text-blue-400 hover:text-blue-300">Sign up</a>
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
