import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Legal() {
  const hero = getPageHero("legal");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Legal</h1>
          <p className="text-lg md:text-2xl text-slate-200">Terms, Privacy & Compliance</p>
        </div>
      </section>

      {/* Legal Content Section */}
      <section className="max-w-4xl mx-auto px-4 py-16">
        <div className="space-y-12">
          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Terms of Service</h2>
            <p className="text-slate-300 mb-4">
              By using FrontDesk Agents, you agree to our terms of service. These terms govern your use of our platform and services.
            </p>
            <a href="#" className="text-blue-400 hover:text-blue-300">Read Full Terms of Service →</a>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Privacy Policy</h2>
            <p className="text-slate-300 mb-4">
              We are committed to protecting your privacy. Our privacy policy explains how we collect, use, and protect your data.
            </p>
            <a href="#" className="text-blue-400 hover:text-blue-300">Read Full Privacy Policy →</a>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Compliance & Security</h2>
            <div className="space-y-3 text-slate-300">
              <p>✓ HIPAA Compliant for Healthcare</p>
              <p>✓ SOC 2 Type II Certified</p>
              <p>✓ GDPR Compliant</p>
              <p>✓ Enterprise-grade Encryption</p>
              <p>✓ Regular Security Audits</p>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Data Protection</h2>
            <p className="text-slate-300">
              Your data is encrypted both in transit and at rest. We maintain strict access controls and regular backups to ensure your information is always protected.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
