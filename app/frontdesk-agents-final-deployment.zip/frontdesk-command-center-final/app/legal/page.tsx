import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Support() {
  const hero = getPageHero("support");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Support Center</h1>
          <p className="text-lg md:text-2xl text-slate-200">We're here to help you succeed</p>
        </div>
      </section>

      {/* Support Content Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
            <h2 className="text-2xl font-bold text-white mb-4">Get in Touch</h2>
            <div className="space-y-4">
              <div>
                <p className="text-slate-400 text-sm">Phone</p>
                <p className="text-white font-semibold">+1 (216) 480-4413</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Email</p>
                <p className="text-white font-semibold">support@frontdeskagents.com</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Hours</p>
                <p className="text-white font-semibold">24/7 Support Available</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
            <h2 className="text-2xl font-bold text-white mb-4">Quick Resources</h2>
            <ul className="space-y-3">
              <li><a href="#" className="text-blue-400 hover:text-blue-300">Knowledge Base</a></li>
              <li><a href="#" className="text-blue-400 hover:text-blue-300">Video Tutorials</a></li>
              <li><a href="#" className="text-blue-400 hover:text-blue-300">API Documentation</a></li>
              <li><a href="#" className="text-blue-400 hover:text-blue-300">Community Forum</a></li>
            </ul>
          </div>
        </div>

        <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              { q: "How do I set up my account?", a: "Follow our setup wizard or contact support for assistance." },
              { q: "What integrations are available?", a: "We support 100+ integrations with popular business tools." },
              { q: "Is there a free trial?", a: "Yes, we offer a 14-day free trial with full features." }
            ].map((faq, idx) => (
              <div key={idx}>
                <h3 className="text-lg font-bold text-white mb-2">{faq.q}</h3>
                <p className="text-slate-300">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
