import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Admin() {
  const hero = getPageHero("admin");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Admin Console</h1>
          <p className="text-lg md:text-2xl text-slate-200">Enterprise control center</p>
        </div>
      </section>

      {/* Admin Features Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-white mb-8">Administration Tools</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            { title: "User Management", description: "Control access and permissions for all team members" },
            { title: "System Settings", description: "Configure global settings and integrations" },
            { title: "Billing & Accounts", description: "Manage subscriptions and billing information" },
            { title: "Security & Compliance", description: "Monitor security logs and compliance reports" },
            { title: "API Management", description: "Manage API keys and integrations" },
            { title: "Support & Resources", description: "Access documentation and support tools" }
          ].map((feature, idx) => (
            <div key={idx} className="bg-slate-800 rounded-lg p-6 border border-slate-700">
              <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
