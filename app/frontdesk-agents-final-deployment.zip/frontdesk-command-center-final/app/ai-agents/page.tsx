import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Setup() {
  const hero = getPageHero("setup");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Setup Wizard</h1>
          <p className="text-lg md:text-2xl text-slate-200">Get started in minutes</p>
        </div>
      </section>

      {/* Setup Steps Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="space-y-6">
          {[
            { step: 1, title: "Connect Your Account", description: "Link your business phone number and email" },
            { step: 2, title: "Configure Settings", description: "Customize greeting, routing, and business hours" },
            { step: 3, title: "Add Users", description: "Invite team members and set permissions" },
            { step: 4, title: "Launch System", description: "Go live and start receiving intelligent calls" }
          ].map((item) => (
            <div key={item.step} className="flex gap-6 bg-slate-800 rounded-lg p-6 border border-slate-700">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600">
                  <span className="text-white font-bold">{item.step}</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">{item.title}</h3>
                <p className="text-slate-300 mt-1">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
