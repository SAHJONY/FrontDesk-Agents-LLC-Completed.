import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Dashboard() {
  const hero = getPageHero("dashboard");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-64 md:h-96 flex items-center justify-center overflow-hidden mb-8">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
      </section>

      {/* Dashboard Content Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <h1 className="text-4xl font-bold text-white mb-8">Dashboard</h1>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { label: "Total Calls", value: "1,234", change: "+12%" },
            { label: "Answered", value: "98%", change: "+2%" },
            { label: "Avg Duration", value: "4m 32s", change: "-15s" },
            { label: "Satisfaction", value: "4.8/5", change: "+0.2" }
          ].map((stat, idx) => (
            <div key={idx} className="bg-slate-800 rounded-lg p-6 border border-slate-700">
              <p className="text-slate-400 text-sm">{stat.label}</p>
              <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
              <p className="text-green-400 text-sm mt-2">{stat.change}</p>
            </div>
          ))}
        </div>

        <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-4">Recent Activity</h2>
          <p className="text-slate-300">Your dashboard is loading...</p>
        </div>
      </section>
    </main>
  );
}
