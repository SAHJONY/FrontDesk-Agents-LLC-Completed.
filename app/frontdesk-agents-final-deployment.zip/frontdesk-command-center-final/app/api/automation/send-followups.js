import fetch from "node-fetch";
import nodemailer from "nodemailer";
import { renderEmail } from "../../../lib/renderEmail.js";

const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY;
const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID;
const AIRTABLE_TABLE_NAME = "Leads";

const SMTP_USER = "frontdeskllc@outlook.com";
const SMTP_PASS = process.env.SMTP_PASS;

const transporter = nodemailer.createTransport({
  host: "smtp.office365.com",
  port: 587,
  secure: false,
  auth: {
    user: SMTP_USER,
    pass: SMTP_PASS
  }
});

const templates = {
  voicemail_followup: "sales",
  demo_confirmation: "sales",
  closing_offer: "sales"
};

export default async function handler(req, res) {
  try {
    const response = await fetch(
      `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_NAME}?filterByFormula=OR({Status}='Voicemail',{Status}='Interested',{Status}='Follow-Up')`,
      { headers: { Authorization: `Bearer ${AIRTABLE_API_KEY}` } }
    );
    const { records } = await response.json();
    if (!records.length) return res.status(200).json({ message: "No pending leads." });

    for (const record of records) {
      const { id, fields } = record;
      const { Email, FirstName, Company, Industry, Status, DemoDate, DemoTime } = fields;
      if (!Email) continue;

      let department = "sales";
      const { html, from, replyTo } = renderEmail({
        template: templates[Status.toLowerCase()] || "sales",
        data: {
          first_name: FirstName,
          company_name: Company,
          industry: Industry,
          demo_date: DemoDate,
          demo_time: DemoTime
        },
        department
      });

      await transporter.sendMail({
        from,
        replyTo,
        to: Email,
        subject: `FrontDesk Command Center – ${Status} update`,
        html
      });

      await fetch(`https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_NAME}/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${AIRTABLE_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fields: { LastEmailSent: new Date().toISOString(), Notes: `Email sent: ${Status}` }
        })
      });
    }

    res.status(200).json({ message: "Emails sent successfully." });
  } catch (error) {
    console.error("Automation error:", error);
    res.status(500).json({ error: "Automation failed", details: error.message });
  }
}
