import Image from "next/image";
import { getPageHero } from "@/lib/siteImages";

export default function Industries() {
  const hero = getPageHero("industries");

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Image Section */}
      <section className="relative w-full h-96 md:h-screen flex items-center justify-center overflow-hidden">
        <Image
          src={hero.src}
          alt={hero.alt}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Industries We Serve</h1>
          <p className="text-lg md:text-2xl text-slate-200">Solutions for every business vertical</p>
        </div>
      </section>

      {/* Industries Grid Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-8">
          {[
            { name: "Healthcare", description: "HIPAA-compliant patient communication and appointment scheduling" },
            { name: "Legal Services", description: "Confidential client intake and case management support" },
            { name: "Real Estate", description: "Lead qualification and property inquiry management" },
            { name: "Hospitality", description: "Guest services and reservation management" },
            { name: "E-commerce", description: "Customer support and order management" },
            { name: "Professional Services", description: "Client onboarding and consultation scheduling" }
          ].map((industry, idx) => (
            <div key={idx} className="bg-slate-800 rounded-lg p-6 border border-slate-700 hover:border-blue-500 transition">
              <h3 className="text-xl font-bold text-white mb-2">{industry.name}</h3>
              <p className="text-slate-300">{industry.description}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
