import type { Metadata } from 'next';
export const dynamic = "force-dynamic";
import { Inter } from 'next/font/google';
import './globals.css';
import { I18nProvider } from '../lib/i18n/provider';
import { AutonomousProvider } from '../lib/autonomous/provider';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from '../components/providers/ThemeProvider';
// Import LanguageProvider to ensure the LanguageContext is available for useLanguage hooks
import { LanguageProvider } from './components/LanguageProvider';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'FrontDesk Agents',
  description: 'AI Receptionist & Revenue Workforce Platform',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      {/*
       * Remove static dark styling from the body element.  The dark mode
       * classes (bg-slate-950 text-slate-100) were forcing the entire
       * application into dark mode regardless of the user's theme
       * preference.  Instead, rely on the ThemeProvider (from
       * next‑themes) to add either a `dark` or `light` class to the
       * document root.  The global styles and Tailwind configuration
       * already define colour variables for both modes, so leaving the
       * body without hardcoded colours allows theme toggling to work.
       */
      <body className={`min-h-screen antialiased`}>
        {/*
         * Wrap the application in LanguageProvider so that any component using the
         * useLanguage hook has access to the LanguageContext. Without this provider
         * components such as the LanguageSelector and other i18n features will throw
         * an error ("useLanguage must be used within a LanguageProvider").
         */}
        <LanguageProvider>
          <ThemeProvider>
            <AuthProvider>
              <I18nProvider>
                <AutonomousProvider>
                  {children}
                </AutonomousProvider>
              </I18nProvider>
            </AuthProvider>
          </ThemeProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
