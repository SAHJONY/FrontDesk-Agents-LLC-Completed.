
# Next.js Client Runtime Crash Hotfix Kit

This kit fixes the black "Application error: a client-side exception has occurred" screen by:
- Keeping `app/layout.tsx` server-only
- Moving providers to `app/providers.tsx` (client)
- Adding `app/error.tsx` error boundary
- Dynamically importing browser-only libs (`jspdf`, `xlsx`, `mic-recorder-to-mp3`)
- Providing a grep sweep script to find offenders
- (Optional) enabling production browser source maps

## Apply
1) Copy `app/providers.tsx` and `app/error.tsx` into your repo's `app/` directory.
2) Open `app/layout.example.tsx` and align your `app/layout.tsx` (no "use client", keep `<html ... suppressHydrationWarning>`, wrap `<Providers>`).
3) Run the sweep: `bash scripts/grep-sweep.sh` and fix matches.
4) (Optional) Merge `snippets/next.config.addon.mjs` into `next.config.mjs`.
5) Build locally: `pnpm build && pnpm start`.
