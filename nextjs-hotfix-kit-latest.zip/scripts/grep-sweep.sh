
#!/usr/bin/env bash
set -euo pipefail

echo "=== Grep Sweep for Common Next.js Client Crash Offenders ==="

if ! command -v rg >/dev/null 2>&1; then
  echo "Please install ripgrep (rg) to run this script."
  exit 1
fi

echo
echo "#1 Illegal: Client files that also declare metadata"
rg -n --hidden 'use client' app | rg -n 'export const metadata' || echo "OK: none found"

echo
echo "#2 Async client components or top-level await in client files"
rg -n --hidden 'use client' app | rg -n 'async function|await ' || echo "OK: none found"

echo
echo "#3 Browser APIs at module scope (move into useEffect)"
rg -n --hidden 'window|document|localStorage|matchMedia' app || echo "OK: none found"

echo
echo "#4 Browser-only libs imported at module scope (use dynamic import)"
rg -n --hidden 'from "jspdf"|from \'jspdf\'|from "xlsx"|from \'xlsx\'|mic-recorder-to-mp3' app || echo "OK: none found"

echo
echo "#5 Server-only SDKs imported in client files (move server-side)"
rg -n --hidden 'from "stripe"|from "twilio"|from "redis"|from "airtable"|from "dotenv"|from "server-only"' app || echo "OK: none found"

echo
echo "Review the matches above and fix per docs/README-HOTFIX.md."
